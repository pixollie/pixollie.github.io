Chuck Sprite Pack — Chuck_Lite
Pixel Art Character Pack (c) Oliver Thomas

Included animations (6 total):
  - Walk_Unarmed
  - Idle_Standing
  - Run_Unarmed
  - Hurt_Unarmed_Standing
  - Die
  - Pistol_Standing_Attack

File format: PNG (transparent background), sprite sheets with JSON metadata, GIFs (preview only, not for in-game use where present).
Both flattened (ready to use) and layered (for customisation: FX, blood, shadow, item layers split out) files included where applicable.

How to Use:
Unity: Import sprite sheet -> Sprite Mode: Multiple -> use Sprite Editor to slice -> set pivot points.
Godot: Use AnimatedSprite2D -> create a SpriteFrames resource -> add frames from sprite sheet or PNGs.
GameMaker: Import sprite sheet via Image Editor, set frame size and FPS, or import individual frames directly.
Other engines (Unreal, Construct, RPG Maker, etc.): all PNGs are transparent, standard format, ready to use.

Contact / follow for updates:
  Instagram: @pix.ollie
  itch.io: https://pixollie.itch.io/
  Twitter: @pix.ollie
